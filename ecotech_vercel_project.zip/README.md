# ECO-TECH 360° Serial Monitor

Static mobile-friendly Arduino serial monitor.

## Deploy on Vercel using GitHub

1. Extract this ZIP.
2. Create a GitHub repository, e.g. `ecotech-serial-monitor`.
3. Upload `index.html`, `vercel.json`, and `README.md` into the repository root.
4. Sign in to Vercel and choose **Add New → Project**.
5. Import the GitHub repository.
6. Choose **Other** as the framework preset. Leave Build Command and Output Directory empty.
7. Press **Deploy** and open the HTTPS URL Vercel provides.

## Connect the Arduino

1. Open the deployed HTTPS page in Chrome.
2. Connect the Arduino Uno using a USB OTG adapter and a data-capable USB cable.
3. Set the baud rate to match `Serial.begin(...)` in your Arduino sketch (default: 9600).
4. Tap **Connect Arduino** and select the USB serial device if Chrome offers it.

## Serial message format

Send one reading per line, in `Parameter: value` format:

```cpp
Serial.println("Water Level: 75%");
Serial.println("Soil Moisture: 420");
Serial.println("Temperature: 28 C");
Serial.println("Humidity: 62%");
Serial.println("Pump Status: OFF");
```

The table displays Water Level, Soil Moisture, Temperature, Humidity, and Pump Status. Solar Tracker messages are ignored.

## Compatibility note

Vercel provides HTTPS hosting, which is required by Web Serial. Actual USB access depends on Android, Chrome, the OTG adapter, cable, and Arduino USB interface. If Chrome does not show a device picker, this page cannot enable USB access by itself.
